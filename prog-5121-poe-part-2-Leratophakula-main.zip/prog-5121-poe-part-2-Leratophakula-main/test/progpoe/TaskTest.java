/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/UnitTests/JUnit4TestClass.java to edit this template
 */
package progpoe;

import org.junit.Test;
import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.junit.jupiter.api.Assertions.assertFalse;
import static org.junit.jupiter.api.Assertions.assertTrue;

/**
 *
 * @author ST10109263
 */
public class TaskTest {
    int numberOfTask;
    
    Task testTasks = new Task(numberOfTask);
    
    public TaskTest() {
    }

    @Test
    public void testCheckTaskDescription() {
    }

    @Test
    public void testCreareTaskID() {
        String expected = "AD:1:BYN";
        String actual = testTasks.createTaskID("Add login Feature", 1, "Robyn");
        assertEquals(expected,actual);
    }
    
    @Test
    public void testCreareTaskIDLoop() 
   {
          String [] developerNames = new String[] {"Mike","Edward"
       , "Samantha", "Glenda"};
          
          String [] taskNames ={"Create Login", "Create Add Tasks", 
              "Create Report", "Create Search"};
          
          String [] testIDs = {"CR:0:IKE","CR:1:ARD","CR:2:THA","CR:3:NDA"};
          
          for (int i = 0; i < developerNames.length; i++) 
          {
             String expected =  testIDs[i];
             String actual = testTasks.createTaskID(taskNames[i], i, developerNames[i] );
             assertEquals(expected,actual);
          }
    }

    @Test
    public void testPrintTaskDeatils() {
    }

    @Test
    public void testReturnTotalhours() {
    }
    
}

 /*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progpoe;

import java.util.Scanner;

/**
 *
 * @author ST10109263
 */
public class Login 
{
    public String UserName = "";
    public String PassWord = "";
    boolean CheckUserName(String UserName)
    {
        boolean UserNamePassed;
        UserNamePassed = false;
        boolean cRule1;
        cRule1 = false;
        boolean cRule2;
        cRule2 = false;
        
        if(UserName.length() <= 5)
        {
            cRule1 = true;
        }
        char[] SpecialChar = {'_'};
        for(int a = 0; a < UserName.length(); a++)
        {
            for(int b = 0; b < 1; b++)
            {
                if(UserName.charAt(a) == SpecialChar[b])
                {
                    cRule2 = true;
                }
             }
         }
        if(cRule1==true && cRule2==true)
        {
            UserNamePassed = true;
        }
        return UserNamePassed;
    }
    boolean CheckPasswordComplexity(String PassWord)
    {
        boolean PassWordPassed;
        PassWordPassed = false;
        boolean cRule1;
        cRule1 = false;
        boolean cRule2;
        cRule2 = false;
        boolean cRule3;
        cRule3 = false;
        boolean cRule4;
        cRule4 = false;
        
        if(PassWord.length() <= 8)
        {
            cRule1 = true;
        }
        char[] alphabets = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
        for(int a = 0; a < PassWord.length(); a++)
        {
            for(int b = 0; b < 26; b++)
            {
                if(PassWord.charAt(a) == alphabets[b])
                {
                    cRule2 = true;
                    b=28;
                    a = PassWord.length()+2;
                }
            }
        }
        char[] numbers = {'0','1','2','3','4','5','6','7','8','9'};
        for(int a = 0; a < PassWord.length(); a++)
        {
            for(int b = 0; b < 10; b++)
            {
                if(PassWord.charAt(a) == numbers[b])
                {
                    cRule3 = true;
                }
            }
        }
         char[] SpecialChar = {'#','~','!','@','$','%','^','&','*','(',')','_','-','+','{','[','}',']','|','?',',','.','/'};
         for(int a = 0; a < PassWord.length(); a++)
         {
             for(int b = 0; b < 23; b++)
             {
                 if(PassWord.charAt(a) == SpecialChar[b])
                 {
                     cRule4 = true;
                 }
             }
         }
        if(cRule1==true && cRule2==true && cRule3==true && cRule4==true)
        {
            PassWordPassed = true;
        }
        return PassWordPassed;
    }
    Boolean LoginUser()
    {
    
        boolean LoginSuccess = false;
        
        return LoginSuccess;
    }
    String registerUser()
    {
        Scanner scan = new Scanner(System.in);
        String FirstName;
        String LastName;
        
        System.out.print("\n\n\t\tRegistration\n\n");
        
        System.out.print("Please Enter Your First Name: ");
        FirstName = scan.next();
        System.out.print("Please Enter Your Last Name: ");
        LastName = scan.next();
        
        while(!CheckUserName(UserName))
        {
            System.out.print("Please Enter Username: ");
            UserName = scan.next();
        }
        
        while(!CheckPasswordComplexity(PassWord))
        {
            System.out.print("Please Enter Your Password: ");
            PassWord = scan.next();
        }   
        return "\n\n\t\tUser Successfully registered!!\n\n";
    }
    String ReturnLoginStatus(boolean Status)
    {
        String ReturnStatus = "";
        if(true)
        {
            ReturnStatus = "You have successfully logged in to the system!";
        }
        else
        {
            ReturnStatus = "Login failed!";
        }
        return ReturnStatus;
    }

    boolean RegisterUser() {
        throw new UnsupportedOperationException("Not supported yet."); // Generated from nbfs://nbhost/SystemFileSystem/Templates/Classes/Code/GeneratedMethodBody
    }
}

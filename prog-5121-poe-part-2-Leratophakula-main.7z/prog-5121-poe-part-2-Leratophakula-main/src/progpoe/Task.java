/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package progpoe;

/**
 *
 * @author ST10109263
 */
public class Task 
{
    String[] taskName;
    int taskNumber;
    String[] taskDescription;
    String[] developerDetails;
    int[] taskDuration;
    String[] taskID;
    String[] taskStatus;
    
    public Task(int numberOfTask)
    {
        taskName = new String[numberOfTask];
        taskNumber = 0;
        taskDescription = new String[numberOfTask];
        developerDetails = new String[numberOfTask];
        taskDuration = new int[numberOfTask];
        taskID = new String[numberOfTask];
        taskStatus = new String[numberOfTask];       
    }
    
    public boolean checkTaskDescription(String description)
    {
         return (description.length() <= 50);                
    }
    public String creareTaskID(int taskNumber)
    {
        taskID[taskNumber] = taskName[taskNumber].substring(0, 2).toUpperCase() + ":" + taskNumber + ":" + developerDetails[taskNumber].substring(developerDetails[taskNumber].length() - 3).toUpperCase(); 
        return taskID[taskNumber];
    }
    public void printTaskDeatils(int TotalTasks)
    {
        System.out.print("\n\nTasks saved so far....\n");
        System.out.print("\n\ttaskID\ttaskName\tDuration\tStatus\tDescription\tDeveloper\n");
        for(int a = 0; a < TotalTasks; a++)
        {
            System.out.print("\n" + (a+1) + ".\t" + taskID[a] + "\t" + taskName[a] + "\t" + taskDuration[a] + "\t" + taskStatus[a] + "\t" + taskDescription[a] + "\t" + developerDetails[a]);            
        }
        System.out.print("\n\nTotal tasks duration : " + returnTotalhours(TotalTasks) + "\n\n");
    }
    
    public int returnTotalhours(int TotalTasks)
    {
        int totalHours = 0;
        for(int a = 0; a < TotalTasks;a++)
            totalHours = totalHours + taskDuration[a];        
        return totalHours;
    }   
}

//Name:
//Surname:
//Student Number:
package progpoe;

import java.util.Scanner;

/**
 *
 * @author ST10109263
 */
public class PROGPOE {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) 
    {
        String UserName;
        String PassWord;
        String FirstName;
        String LastName;
        boolean LoginStatus = false;
        
        Scanner Input = new Scanner(System.in);
        Login log = new Login();
        System.out.print(log.RegisterUser());
        
        LoginStatus = log.LoginUser();
        log.ReturnLoginStatus(LoginStatus);
        boolean UserNameCorrect;
        UserNameCorrect = false;
        System.out.println("Enter UserName: ");
        UserName = Input.next();
        UserNameCorrect = checkUserName(UserName);
        if(UserNameCorrect == true)
        {
            System.out.println("Username successfully captured");            
        }
        else
        {
            System.out.println("Username is not correctly formatted, please ensure that your username contains an underscore and is no more than 5 characters in length.");
        }
            

        String Password;
        boolean PasswordCorrect;
        PasswordCorrect = false;
        System.out.println("Enter password: ");
        Password = Input.next();
        PasswordCorrect = checkPasswordComplexity(Password);
        if(PasswordCorrect == true)
        {
            System.out.println("Password Successfully caputured");            
        }
        else
        {
            System.out.println("Password is not correctly formatted, please ensure that the password contains at least 8 characters, a capital letter, a number and a special character.");
        }
        Scanner scan = new Scanner(System.in);
        int numberOfTasks;
        
        System.out.print("Welcome to EasyKanban");
        System.out.print("\n\nHow many tasks do you wish to enter : ");
        numberOfTasks = scan.nextInt();
        if(numberOfTasks > 0)
        {
            Task task1 = new Task(numberOfTasks);
        
            System.out.print("\n\nThank you, You may now start capturing the tasks,\n should you wish to Quit just press 3..");
            for(int a = 0; a < numberOfTasks; a++)
            {
                System.out.print("\n\n1). Add tasks");
                System.out.print("\n2). Show report");
                System.out.print("\n3). Quit\n\nPick and option : ");
            
                int option = scan.nextInt();
                if(option == 1)
                {                  
                    task1.taskNumber = a;
                    System.out.print("Enter this task's name : ");
                    task1.taskName[a] = scan.next();
                    System.out.print("Enter this task's description : ");
                    task1.taskDescription[a] = scan.next();
                    while(!task1.checkTaskDescription(task1.taskDescription[a]))
                    {
                        System.out.print("Description shouldn't be more than 50 characters, Please try again : ");
                        task1.taskDescription[a] = scan.next();                    
                    }                 
                    
                    System.out.print("Enter this task's developer details : ");
                    task1.developerDetails[a] = scan.next();
                    System.out.print("Enter this task's duration (in hours) : ");
                    task1.taskDuration[a] = scan.nextInt();
                    System.out.print("Enter this task status, Choose one from the below \n");
                    System.out.print("\n1. To Do");
                    System.out.print("\n2. Done");
                    System.out.print("\n3. Doing");
                    System.out.print("\nenter number before the option of your choice : ");
                    int choice = scan.nextInt();
                    while(choice < 1 || choice > 3)
                    {
                        System.out.print("\nRange is between 1 and 3, please try again : ");
                        choice = scan.nextInt();                    
                    }
                    if(choice == 1)
                        task1.taskStatus[a] = "To Do";
                    if(choice == 2)
                        task1.taskStatus[a] = "Done";
                    if(choice == 3)
                        task1.taskStatus[a] = "Doing";
                    
                    task1.creareTaskID(a);                        
                }
                if(option == 2)
                {
                    task1.printTaskDeatils(a);
                    a--;
                }
                if(option == 3)
                {
                    a = numberOfTasks;
                }            
            }    
        }
            }
        
    static boolean checkUserName(String UsrName)
    {
        boolean UserNamePassed;
        UserNamePassed = false;
        boolean c1;
        c1 = false;
        boolean c2;
        c2 = false;
        
        if(UsrName.length() <= 5)
        {
            c1 = true;
        }
        char[] SpecialChar = {'_'};
        for(int a = 0; a < UsrName.length(); a++)
        {
            for(int b = 0; b < 1; b++)
            {
                if(UsrName.charAt(a) == SpecialChar[b])
                {
                    c2 = true;
                }
             }
         }
        if(c1==true && c2==true)
        {
            UserNamePassed = true;
        }
        return UserNamePassed;
    }
    static boolean checkPasswordComplexity(String Pword)
    {
        boolean PassWordPassed;
        PassWordPassed = false;
        boolean c1;
        c1 = false;
        boolean c2;
        c2 = false;
        boolean c3;
        c3 = false;
        boolean c4;
        c4 = false;
        
        if(Pword.length() <= 8)
        {
            c1 = true;
        }
        char[] alphabets = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
        for(int a = 0; a < Pword.length(); a++)
        {
            for(int b = 0; b < 26; b++)
            {
                if(Pword.charAt(a) == alphabets[b])
                {
                    c2 = true;
                    b=28;
                    a = Pword.length()+2;
                }
            }
        }
        char[] numbers = {'0','1','2','3','4','5','6','7','8','9'};
        for(int a = 0; a < Pword.length(); a++)
        {
            for(int b = 0; b < 10; b++)
            {
                if(Pword.charAt(a) == numbers[b])
                {
                    c3 = true;
                }
            }
        }
         char[] SpecialChar = {'#','~','!','@','$','%','^','&','*','(',')','_','-','+','{','[','}',']','|','?',',','.','/'};
         for(int a = 0; a < Pword.length(); a++)
         {
             for(int b = 0; b < 23; b++)
             {
                 if(Pword.charAt(a) == SpecialChar[b])
                 {
                     c4 = true;
                 }
             }
         }
        if(c1==true && c2==true && c3==true && c4==true)
        {
            PassWordPassed = true;
        }
        return PassWordPassed;
    }
}